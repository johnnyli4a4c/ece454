#include <stdio.h>

/* A fake client api that does nothing useful other than to demonstrate
 * the packaging for A4, ECE 454.
 */

int f(int a) {
    /* a silly function */
    return a*2;
}
